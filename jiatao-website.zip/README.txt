# Jiatao Industry Website - Deployment Guide

## 文件说明

| 文件 | 说明 |
|------|------|
| `index.html` | 完整网站（单文件，无需其他依赖） |
| `README.txt` | 本说明文档 |

## 网站特性

- ✅ 单页长滚动设计（Home / About / Products / Story / Contact）
- ✅ 完全响应式（手机/平板/桌面）
- ✅ 英文内容，B2B制造业风格
- ✅ 8大产品分类展示
- ✅ 公司时间轴（2009-2025）
- ✅ 询盘表单（Formspree集成）
- ✅ 零外部依赖（除Google Fonts）

## 部署步骤（Cloudflare Pages）

### 1. 注册/登录 Cloudflare
- 访问 https://dash.cloudflare.com
- 使用你的账号：724097@qq.com

### 2. 创建 Pages 项目
1. 左侧菜单 → **Pages**
2. 点击 **Create a project**
3. 选择 **Upload assets**
4. 项目名填写：`jiatao-industry`
5. 拖拽上传 `index.html` 文件
6. 点击 **Deploy**

### 3. 绑定域名（partyproducts.cn）
1. 进入项目 → **Custom domains**
2. 点击 **Set up a custom domain**
3. 输入：`partyproducts.cn`
4. Cloudflare 会提供 DNS 记录（类似 `xxx.pages.dev`）

### 4. GoDaddy DNS 配置
登录你的 GoDaddy 账号，修改 DNS：

| 类型 | 主机 | 值 |
|------|------|-----|
| CNAME | www | `你的项目名.pages.dev` |
| A | @ | `185.199.108.153` |

等待 5-10 分钟生效。

## 图片替换指南

当前使用 CSS/SVG 占位，替换实际产品图步骤：

### 方法1：直接替换（简单）
1. 准备产品图片（建议尺寸 800x600px，JPG格式）
2. 使用 Cloudflare R2 或图床上传，获得链接
3. 在 `index.html` 中搜索 `REPLACE IMAGE`
4. 替换对应 CSS 背景或添加 `<img>` 标签

### 方法2：本地图片（推荐长期）
1. 创建 `images/` 文件夹
2. 放入图片：`balloons-01.jpg`, `pinata-01.jpg` 等
3. 修改 HTML 中的图片路径：`./images/balloons-01.jpg`
4. 重新上传整个文件夹到 Cloudflare Pages

### 占位图位置对照

| 位置 | 查找标记 | 建议替换图 |
|------|---------|-----------|
| 首页横幅 | Hero Image | 工厂全景或派对场景 |
| 关于我们 | Factory Photo | 工厂设备或团队照 |
| 产品卡片 | 8个 REPLACE IMAGE 标签 | 各分类产品实拍 |

## 表单配置（重要）

当前表单使用 Formspree 占位，需替换为你的表单 ID：

1. 注册 https://formspree.io（免费版支持 50 条/月）
2. 创建新表单，获得 ID（如 `xrbzpebr`）
3. 在 `index.html` 中搜索：`YOUR_FORM_ID`
4. 替换为实际 ID

或改为邮件链接：
```html
<!-- 替换整个 form 标签 -->
<a href="mailto:info@partymaker.cn?subject=Inquiry from Website" class="cta-button">Email Us</a>
```

## 内容修改

无需懂代码，直接编辑 `index.html`：

| 修改项 | 查找文本 | 说明 |
|--------|---------|------|
| 公司数据 | `16+`, `500+`, `100+`, `$300M` | 统计数字 |
| 联系方式 | `info@partymaker.cn` | 邮箱地址 |
| 产品描述 | 各 product-info 下的 p 标签 | 产品文案 |
| 时间轴 | `2009`, `2012` 等年份 | 发展历程 |

## 技术细节

- **构建工具**: 纯 HTML + CSS，无 JavaScript 框架
- **CSS 特性**: CSS Variables, Flexbox, Grid, 媒体查询
- **浏览器支持**: Chrome 90+, Firefox 88+, Safari 14+, Edge 90+
- **性能**: 单文件 ~35KB，加载时间 < 1s

## 故障排除

| 问题 | 解决 |
|------|------|
| 页面空白 | 检查文件编码是否为 UTF-8 |
| 样式错乱 | 确认上传的是完整 `index.html`，非片段 |
| 域名不生效 | GoDaddy DNS 传播需 5-10 分钟，清除浏览器缓存 |
| 表单提交失败 | 确认 Formspree ID 已替换，或改用邮件链接 |

## 后续优化建议

1. **添加 Google Analytics**: 在 `<head>` 插入跟踪代码
2. **SEO 优化**: 添加 meta keywords, Open Graph 标签
3. **多语言**: 复制页面改为 `index-cn.html`
4. **产品详情页**: 当前为单页，如需独立产品页需扩展结构

## 支持

部署遇到问题，提供：
- Cloudflare Pages 报错截图
- GoDaddy DNS 设置截图
- 浏览器控制台错误（F12 → Console）
